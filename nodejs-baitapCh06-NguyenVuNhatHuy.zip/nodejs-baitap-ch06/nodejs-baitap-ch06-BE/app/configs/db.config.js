module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "admin23!%",
  DB: "product_management",
  dialect: "mysql",
};
